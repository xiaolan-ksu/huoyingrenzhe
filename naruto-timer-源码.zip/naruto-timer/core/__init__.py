"""替身计时器核心模块。

拆分说明：
    config.py        配置加载与保存
    detect.py        纯逻辑：颜色判定、计数、下降沿检测（不依赖 Qt，可单测）
    sampler.py       屏幕取样：截取检测点附近的小块区域取色
    foreground.py    前台窗口判断，避免在桌面上胡乱检测
    overlay.py       悬浮面板：按钮、倒计时、进度条（全部自绘）
    debug_overlay.py 检测点可视化，支持拖动标定
    settings.py      设置窗口（只调判定参数）
    chooser.py       启动时选 P1 / P2

早期版本有个 hotkeys.py 做全局热键监听，现已全部改成面板按钮，该模块已删除。
"""
