"""调试覆盖层：把检测点画在屏幕上，并且可以直接拖动标定。

每个检测点画一个圆圈 + 十字 + 编号，颜色表示当前判定结果：

    绿 = bright（亮蓝，可用）
    黄 = gold（赤金，也是可用）
    灰 = dark（暗青，已用掉）
    红 = 没识别出来（通常是偏了或压在描边上）

按 F3 打开后，左键拖动任意圆圈到豆的位置，松手就会把新坐标写回
config.json。这个模式下窗口会接收鼠标（否则拖不动），所以标定期间
没法操作游戏，按 F3 关掉即可恢复。
"""

from __future__ import annotations

from typing import Any

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QGuiApplication, QPainter, QPen
from PyQt6.QtWidgets import QWidget

STATE_COLORS = {
    "bright": QColor(80, 230, 150),
    "gold": QColor(255, 200, 60),
    "dark": QColor(150, 150, 150),
}

HINT = "拖动圆圈对准豆的中心，松手自动保存 · 按 F3 关闭"


class DebugOverlay(QWidget):
    """全屏覆盖层，显示并能拖动检测点。"""

    points_moved = pyqtSignal()

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()

        screen = QGuiApplication.primaryScreen()
        if screen is not None:
            self.setGeometry(screen.geometry())

        # 不能加 WindowTransparentForInput，否则收不到鼠标就没法拖
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setMouseTracking(True)

        self._points: list[tuple[int, int, str, str | None]] = []
        self._dragging: int | None = None

    def points(self) -> list[tuple[int, int, str, str | None]]:
        return list(self._points)

    def set_points(self, points: list[tuple[int, int, str, str | None]]) -> None:
        # 拖动过程中不要被轮询结果冲掉
        if self._dragging is not None:
            return
        self._points = points
        self.update()

    # ---------- 鼠标交互 ----------

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton:
            return

        pos = event.position().toPoint()
        for index, (x, y, _label, _state) in enumerate(self._points):
            if (pos.x() - x) ** 2 + (pos.y() - y) ** 2 <= 18**2:
                self._dragging = index
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
                return

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._dragging is None:
            return

        pos = event.position().toPoint()
        _, _, label, state = self._points[self._dragging]
        self._points[self._dragging] = (pos.x(), pos.y(), label, state)
        self.update()

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if self._dragging is None:
            return

        self._dragging = None
        self.unsetCursor()
        self.points_moved.emit()

    # ---------- 绘制 ----------

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        for x, y, label, state in self._points:
            color = STATE_COLORS.get(state, QColor(255, 90, 90)) if state else QColor(255, 90, 90)

            # 圈画小一点（豆本身也就 20px），中心加个实心点当准心，
            # 这样拖的时候能明确对到豆的正中央，不会对到边上
            painter.setPen(QPen(color, 2))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(x - 6, y - 6, 12, 12)
            painter.drawLine(x - 11, y, x + 11, y)
            painter.drawLine(x, y - 11, x, y + 11)

            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(color)
            painter.drawEllipse(x - 1, y - 1, 3, 3)

            painter.setPen(QPen(color, 1))
            painter.setFont(QFont("Microsoft YaHei", 8))
            painter.drawText(x + 12, y - 11, f"{label} {state or '?'}")

        # 顶部提示条
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(10, 40, 40, 210))
        painter.drawRoundedRect(20, 14, 460, 30, 6, 6)
        painter.setPen(QPen(QColor(255, 255, 255, 235), 1))
        painter.setFont(QFont("Microsoft YaHei", 10))
        painter.drawText(32, 34, HINT)
