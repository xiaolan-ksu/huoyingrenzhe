"""配置加载。

设计要点：
1. 内置 DEFAULTS 兜底，config.json 只写你想改的字段即可。
2. 递归合并（dict 逐层合并，其余类型直接覆盖），这样旧配置文件
   在程序升级后不会因为缺字段而崩掉。
3. 以 "_" 开头的键视为注释，加载时剔除，避免污染运行时字典。

坐标与色值说明：
    下面 DEFAULTS 里的检测点坐标和颜色区间，全部来自本机实测
    （决斗场 P1/P2，1920x1080 全屏）。换了分辨率、换了场地
    （训练场豆位比决斗场靠左约 25px）都要重新标定，用面板上的
    标定按钮拖圆圈即可自动写回 config.json。
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "countdown_seconds": 15.0,
    "player": "p1",
    "ask_player_on_start": True,
    "poll_interval_ms": 100,
    "tolerance": 4,
    "dpi_unaware": True,
    "window": {
        "x": 1660,
        "y": 940,
        "width": 240,
        "height": 130,
    },
    "detection": {
        "enabled": True,
        "margin": 4,
        "confirm_frames": 2,
        "min_trigger_gap": 3.0,
        "prefix_check": True,
        # 找模拟器窗口算画面区域；留空则整屏当画面。
        # 填了标题关键词后，窗口模式、最大化、改分辨率都能自动跟随。
        "map_to_window": "MuMu安卓设备",
        "reference_size": [1920, 1080],
        "require_foreground": ["火影", "MuMu", "雷电", "夜神", "LDPlayer", "BlueStacks"],
        # 屏幕绝对坐标，从左到右排列（实测于 1920x1080 全屏决斗场）
        "left_points": [
            [212, 126], [242, 127], [274, 127], [303, 125],
        ],
        # 右侧同样按「从屏幕外侧往里」排列
        "right_points": [
            [1623, 126], [1651, 127], [1682, 124], [1710, 124],
        ],
        # 菱形采样：尺寸按 1920x1080 基准给，实际按画面缩放倍数放大。
        # 豆主体约 20px，菱形取它的六七成，正好避开外圈描边。
        # 判定用严格多数决（见 sampler._decide），宁可漏读也不乱给状态。
        "bead_sample": {
            "diamond_w": 9,
            "diamond_h": 13,
            "search_radius": 4,
            "search_step": 2,
            "search_scale": 0.6,
            "min_samples": 12,
            "majority_pct": 65,
        },
        # 三个区间互不重叠（靠 B 通道区分青/金，靠 R 通道区分金/暗），
        # 判定时按 gold → bright → dark 顺序匹配，第一个命中的即结果。
        # 数值按本机实测样本向外留了余量，抗锯齿和视频压缩造成的抖动落不出去。
        "colors": {
            # 已用掉：暗蓝实心，实测 (25~27, 50~57, 96~99)
            "dark":   {"min": [8, 28, 70],    "max": [75, 80, 125]},
            # 可用（金色）：实测 (189~255, 189~246, 0~125)
            "gold":   {"min": [165, 150, 0],  "max": [255, 255, 145]},
            # 可用（青蓝）：实测 (141~177, 224~239, 245~251)
            "bright": {"min": [100, 180, 210], "max": [220, 255, 255]},
        },
    },
}


def _strip_comments(node: Any) -> Any:
    """递归移除以 _ 开头的键（JSON 里没法写注释，用这种方式代替）。"""
    if isinstance(node, dict):
        return {k: _strip_comments(v) for k, v in node.items() if not str(k).startswith("_")}
    if isinstance(node, list):
        return [_strip_comments(v) for v in node]
    return node


def _merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """把 override 合并进 base 的副本，dict 递归，其余覆盖。"""
    result = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def load(path: Path) -> dict[str, Any]:
    """读取配置文件；文件不存在或格式错误时退回默认值。"""
    cfg = copy.deepcopy(DEFAULTS)
    if not path.exists():
        return cfg

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"[配置] {path.name} 格式有误，已使用默认值：{exc}")
        return cfg

    return _merge(cfg, _strip_comments(raw))


def save_runtime(path: Path, cfg: dict[str, Any]) -> None:
    """把设置窗口改过的字段写回 config.json。

    只改这几项，其余内容和 _ 开头的注释原样保留，避免把用户手写的
    其他配置冲掉。
    """
    try:
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except json.JSONDecodeError:
        raw = {}

    raw["countdown_seconds"] = cfg["countdown_seconds"]
    detection = raw.setdefault("detection", {})
    detection["confirm_frames"] = cfg["detection"]["confirm_frames"]
    detection["min_trigger_gap"] = cfg["detection"]["min_trigger_gap"]

    path.write_text(
        json.dumps(raw, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def save_player(path: Path, player: str) -> None:
    """记住这次选的位置，下次启动默认选中它。"""
    try:
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except json.JSONDecodeError:
        raw = {}
    raw["player"] = player
    path.write_text(
        json.dumps(raw, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def save_detection_points(
    path: Path,
    left: list[tuple[int, int]],
    right: list[tuple[int, int]],
) -> None:
    """把标定好的检测点写回 config.json。以 _ 开头的注释字段原样保留。"""
    try:
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except json.JSONDecodeError:
        raw = {}

    detection = raw.setdefault("detection", {})
    detection["left_points"] = [[int(x), int(y)] for x, y in left]
    detection["right_points"] = [[int(x), int(y)] for x, y in right]

    path.write_text(
        json.dumps(raw, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def validate(cfg: dict[str, Any]) -> list[str]:
    """返回配置里值得提醒的问题（不阻断启动）。"""
    warnings: list[str] = []

    if cfg["countdown_seconds"] <= 0:
        warnings.append("countdown_seconds 必须大于 0")

    if not 10 <= cfg["poll_interval_ms"] <= 1000:
        warnings.append("poll_interval_ms 建议在 10-1000 之间")

    det = cfg["detection"]
    for side in ("left_points", "right_points"):
        points = det.get(side) or []
        if len(points) < 4:
            warnings.append(f"detection.{side} 少于 4 个点，检测会自动跳过该侧")
        for pt in points:
            if not (isinstance(pt, (list, tuple)) and len(pt) == 2):
                warnings.append(f"detection.{side} 里有格式错误的坐标：{pt!r}")

    return warnings
