"""读取 Windows 前台窗口标题。

用途：判断游戏（或模拟器）是否在前台。只有在前台时才做像素检测，
否则桌面上任意内容都可能被误判成"替身被消耗"，导致倒计时刷屏。
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes


def _sanitize(text: str) -> str:
    """去掉不可打印字符（零宽空格、控制符等）。

    Windows 窗口标题里确实会混进 \\u200b 这类不可见字符。它肉眼看不见，
    但往下传到控制台会触发 GBK 编码异常，日志也会变得难以对照。
    """
    return "".join(ch for ch in text if ch.isprintable()).strip()


def get_foreground_title() -> str:
    """返回前台窗口标题，取不到时返回空串。"""
    if sys.platform != "win32":
        return ""

    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ""

        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return ""

        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        return _sanitize(buffer.value)
    except Exception:
        return ""


def title_matches(title: str, keywords: list[str]) -> bool:
    """标题是否包含任一关键词。关键词列表为空表示不做限制。"""
    if not keywords:
        return True

    lowered = title.lower()
    return any(keyword.lower() in lowered for keyword in keywords if keyword)


def find_window_client_rect(keyword: str) -> tuple[int, int, int, int] | None:
    """按标题关键词找可见窗口，返回客户区在屏幕上的 (x, y, 宽, 高)。

    客户区排除了标题栏和边框，正好对应游戏画面区域，用它做坐标映射最准。
    找不到返回 None。
    """
    if sys.platform != "win32" or not keyword:
        return None

    user32 = ctypes.windll.user32
    found: list[tuple[int, int, int, int]] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def callback(hwnd, _lparam):
        if not user32.IsWindowVisible(hwnd):
            return True

        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True

        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        if keyword.lower() not in buffer.value.lower():
            return True

        client = wintypes.RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(client)):
            return True

        width = client.right - client.left
        height = client.bottom - client.top
        # 太小的多半是隐藏的辅助窗口，跳过
        if width < 320 or height < 240:
            return True

        origin = wintypes.POINT(0, 0)
        if not user32.ClientToScreen(hwnd, ctypes.byref(origin)):
            return True

        found.append((origin.x, origin.y, width, height))
        return False  # 已经找到，停止枚举

    try:
        user32.EnumWindows(callback, 0)
    except Exception:
        return None

    return found[0] if found else None
