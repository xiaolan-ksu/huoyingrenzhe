"""屏幕取样：把 1920x1080 逻辑坐标映射到当前画面，并按菱形区域读豆。

坐标系（换分辨率不用重标的关键）：

    config.json 里的检测点永远按 1920x1080 逻辑坐标存。运行时按
    「NGUI fixed-height + 左右各自贴边」换算到实际画面区域：

        高度方向：scale = 画面高度 / 1080
        左侧 HUD：x = 画面左边界 + 逻辑x * scale
        右侧 HUD：x = 画面右边界 - (1920 - 逻辑x) * scale

    这样 1080p / 1440p / 4K 用同一套坐标，左右 HUD 各自贴着屏幕边缘，
    中间的场景宽窄变化不影响豆的位置。

采样策略（三层，从准到宽）：

    1. 中心单像素：实测数据证明最能区分"亮"和"已用掉"，优先采信
    2. 菱形区域投票：中心踩到过渡色时，按豆的竖向菱形轮廓取 9x13 区域
    3. 亮核搜索：前两层都没结论时，在 ±8 像素内找亮像素最集中的位置

    第 1 层不能省。豆用掉后只是变暗/变空心，四周边框仍是原来的颜色，
    如果一上来就做区域投票，会被描边骗成"还能用"，剩余数永远不变。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from PyQt6.QtGui import QGuiApplication, QImage

from .detect import BRIGHT, DARK, GOLD, RGB, Point, classify


@dataclass
class Region:
    """一块待截取的区域，以及落在其中的检测点（都用屏幕绝对坐标）。"""

    x: int
    y: int
    width: int
    height: int
    points: list[Point] = field(default_factory=list)


def make_region(points: list[Point], margin: int = 4) -> Region | None:
    """把一组点包进一个矩形，四周留 margin 像素。"""
    if not points:
        return None

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    x0, y0 = min(xs), min(ys)

    return Region(
        x=x0 - margin,
        y=y0 - margin,
        width=max(xs) - x0 + margin * 2 + 1,
        height=max(ys) - y0 + margin * 2 + 1,
        points=list(points),
    )


class ScreenSampler:
    """负责截屏并把像素翻成颜色标签。"""

    def __init__(self, cfg: dict[str, Any]) -> None:
        self._screen = QGuiApplication.primaryScreen()
        # 系统开了 125%/150% 缩放时，grabWindow 拿到的图会比请求的逻辑尺寸
        # 大 dpr 倍，取色下标要跟着放大，否则全部偏移。DPI 不感知模式下该值是 1。
        self._dpr = self._screen.devicePixelRatio() if self._screen is not None else 1.0

        det = cfg["detection"]
        self._palette = det["colors"]
        self._tolerance = int(cfg["tolerance"])
        self._margin = int(det["margin"])
        self._left_points: list[Point] = [tuple(p) for p in det["left_points"]]  # type: ignore[misc]
        self._right_points: list[Point] = [tuple(p) for p in det["right_points"]]  # type: ignore[misc]
        self._reference = tuple(det.get("reference_size") or (1920, 1080))

        # 菱形采样参数：尺寸按 1920x1080 基准给出，实际使用时按 scale 放大
        bead = det.get("bead_sample") or {}
        self._bead_w = int(bead.get("diamond_w", 9))
        self._bead_h = int(bead.get("diamond_h", 13))
        self._search_radius = int(bead.get("search_radius", 4))
        self._search_step = max(1, int(bead.get("search_step", 2)))
        # 搜索时用更小的菱形：只判断"这里像不像豆心"，不需要完整轮廓
        self._search_scale = float(bead.get("search_scale", 0.6))
        # 多数决门槛：已知像素至少这么多个，且某一方占比达到 majority_pct
        self._min_samples = int(bead.get("min_samples", 12))
        self._majority_pct = int(bead.get("majority_pct", 65))

        self._area: tuple[int, int, int, int] = self._full_screen()
        self._origin = (0.0, 0.0)
        self._scale = 1.0
        self._area_w = 0.0
        self._refresh()

        self.left_region: Region | None = None
        self.right_region: Region | None = None
        self._rebuild()
        self._last_error: str | None = None

    # ---------- 区域与映射 ----------

    def _full_screen(self) -> tuple[int, int, int, int]:
        if self._screen is None:
            return (0, 0, 1920, 1080)
        geo = self._screen.geometry()
        return (geo.x(), geo.y(), geo.width(), geo.height())

    def _refresh(self) -> None:
        """按当前画面区域重算映射参数。

        fixed-height：HUD 高度随画面高度等比，宽度方向左右各自贴边。
        16:9 画面下与等比缩放完全等价，超宽/偏窄画面下不会把左右 HUD
        往中间挤。
        """
        ax, ay, aw, ah = self._area
        _, ref_h = self._reference

        self._origin = (float(ax), float(ay))
        self._area_w = float(aw)
        self._scale = (ah / ref_h) if ref_h else 1.0

    @property
    def last_error(self) -> str | None:
        return self._last_error

    @property
    def scale(self) -> float:
        return self._scale

    @property
    def origin(self) -> tuple[float, float]:
        return self._origin

    @property
    def area(self) -> tuple[int, int, int, int]:
        return self._area

    def set_window(self, rect: tuple[int, int, int, int] | None) -> bool:
        """设置画面区域；传 None 表示用整个主屏。

        返回 True 表示映射发生了变化（调用方可以用来打日志）。
        """
        target = rect if rect is not None else self._full_screen()
        if target == self._area:
            return False

        self._area = target
        self._refresh()
        self._rebuild()
        return True

    def _map(self, point: Point) -> Point:
        """逻辑坐标（1920x1080）→ 屏幕坐标。"""
        lx, ly = point
        ref_w, _ = self._reference
        scale = self._scale

        if lx < ref_w / 2:
            x = self._origin[0] + lx * scale
        else:
            # 右侧 HUD 贴住画面右边界往回数
            x = self._origin[0] + self._area_w - (ref_w - lx) * scale
        y = self._origin[1] + ly * scale
        return (int(round(x)), int(round(y)))

    def unmap(self, point: Point) -> Point:
        """屏幕坐标 → 逻辑坐标（标定回写时用）。"""
        if not self._scale:
            return point

        px, py = point
        ref_w, _ = self._reference
        scale = self._scale

        lx_left = (px - self._origin[0]) / scale
        if lx_left < ref_w / 2:
            lx = lx_left
        else:
            right_edge = self._origin[0] + self._area_w
            lx = ref_w - (right_edge - px) / scale

        ly = (py - self._origin[1]) / scale
        return (int(round(lx)), int(round(ly)))

    def set_points(self, left: list[Point], right: list[Point]) -> None:
        """手工标定后替换检测点。"""
        self._left_points = list(left)
        self._right_points = list(right)
        self._rebuild()

    def _rebuild(self) -> None:
        left = [self._map(p) for p in self._left_points]
        right = [self._map(p) for p in self._right_points]
        # 留白要够菱形半径，否则截取区域比采样区域还小，边缘会被裁掉
        margin = max(self._margin, int(round(self._bead_h * self._scale)) + 2)
        self.left_region = make_region(left, margin)
        self.right_region = make_region(right, margin)

    # ---------- 取色 ----------

    def _grab(self, region: Region) -> QImage | None:
        if self._screen is None:
            self._last_error = "找不到主屏幕"
            return None

        pixmap = self._screen.grabWindow(0, region.x, region.y, region.width, region.height)
        if pixmap.isNull():
            self._last_error = "截屏失败（区域可能超出屏幕范围）"
            return None

        return pixmap.toImage()

    def sample(self, region: Region | None) -> list[str | None]:
        """返回该区域每个点的颜色标签，读不到的给 None。"""
        if region is None:
            return []

        image = self._grab(region)
        if image is None:
            return [None] * len(region.points)

        result: list[str | None] = []
        for px, py in region.points:
            col = int((px - region.x) * self._dpr)
            row = int((py - region.y) * self._dpr)
            result.append(self._read_point(image, col, row, region))
        return result

    def _read_point(self, image: QImage, col: int, row: int, region: Region) -> str | None:
        """读一颗豆：中心优先，菱形兜底，最后找亮核。"""
        max_col = int(region.width * self._dpr) - 1
        max_row = int(region.height * self._dpr) - 1

        def clamp_x(value: int) -> int:
            return min(max(value, 0), max_col)

        def clamp_y(value: int) -> int:
            return min(max(value, 0), max_row)

        def read(c: int, r: int) -> str | None:
            color = image.pixelColor(clamp_x(c), clamp_y(r))
            return classify(
                (color.red(), color.green(), color.blue()),
                self._palette,
                self._tolerance,
            )

        # 1. 中心单像素。豆用掉后边框还是亮的，先看中心能避开描边干扰。
        center = read(col, row)
        if center is not None:
            return center

        # 2. 菱形区域投票
        voted = self._diamond_vote(image, col, row, read)
        if voted is not None:
            return voted

        # 3. 亮核搜索：附近找亮像素最集中的位置
        return self._search_light_core(image, col, row, read)

    def _diamond_vote(self, image: QImage, col: int, row: int, read) -> str | None:
        """按豆的竖向菱形轮廓取一圈像素，用严格多数决判定。

        豆是竖菱形（顶尖→中部最宽→底尖），方形采样会把四个角上的背景
        也算进来。菱形尺寸取豆主体的六七成，避开外圈描边。

        为什么要严格多数决：背景色、UI 描边、特效残影里总会有零星几个
        像素刚好落进颜色区间。早先按"亮像素 ≥4 个就判亮"的写法实测下来，
        屏幕上随意取 40 个位置会有 26 次判出豆来，全是误报。改成要求
        明确多数后，这种巧合凑不出结论。
        """
        light, dark, gold, unknown = self._diamond_counts(image, col, row, read)
        return self._decide(light, dark, gold, unknown)

    def _diamond_counts(self, image: QImage, col: int, row: int, read, scale: float = 1.0):
        """统计以 (col,row) 为中心的菱形区域里各类像素数。"""
        eff = self._scale * self._dpr * scale
        half_w = max(2, int(round(self._bead_w * eff)) // 2)
        half_h = max(3, int(round(self._bead_h * eff)) // 2)

        light = dark = gold = unknown = 0
        for dy in range(-half_h, half_h + 1):
            for dx in range(-half_w, half_w + 1):
                # 菱形方程 |dx|/half_w + |dy|/half_h <= 1，整数运算避免浮点误差
                if abs(dx) * half_h + abs(dy) * half_w > half_w * half_h:
                    continue
                name = read(col + dx, row + dy)
                if name is None:
                    unknown += 1
                elif name == DARK:
                    dark += 1
                elif name == GOLD:
                    gold += 1
                else:
                    light += 1
        return light, dark, gold, unknown

    def _decide(self, light: int, dark: int, gold: int, unknown: int) -> str | None:
        """多数决：样本够多，且某一方占绝对多数才给结论。

        拿不准就返回 None。这里宁可漏读一次（有脏帧保护兜底，下一帧会
        补上），也不能乱给状态——错一次就是一次假倒计时。
        """
        bright = light + gold
        known = bright + dark
        if known < self._min_samples:
            return None

        if bright * 100 >= known * self._majority_pct:
            return GOLD if gold >= light else BRIGHT
        if dark * 100 >= known * self._majority_pct:
            return DARK
        return None

    def _search_light_core(self, image: QImage, col: int, row: int, read) -> str | None:
        """在中心附近找一个能给出明确结论的位置。

        用途：坐标因为分辨率变化偏了几个像素时自动找回豆心；豆被特效
        挡住一半时，从露出的那一半读。

        只在中心和小菱形都没结论时才走到这里，所以不是每帧都跑，性能
        影响可以忽略。搜索本身也用同样的多数决，不会在杂色区域乱判。
        """
        eff = self._scale * self._dpr
        radius = max(2, int(round(self._search_radius * eff)))
        step = max(1, int(round(self._search_step * eff)))

        best_state: str | None = None
        best_score = 0.0

        for dy in range(-radius, radius + 1, step):
            for dx in range(-radius, radius + 1, step):
                if dx == 0 and dy == 0:
                    continue
                light, dark, gold, unknown = self._diamond_counts(
                    image, col + dx, row + dy, read, scale=self._search_scale
                )
                bright = light + gold
                known = bright + dark
                if known < max(6, self._min_samples // 2):
                    continue

                if bright >= dark:
                    score = bright / known
                    state = GOLD if gold >= light else BRIGHT
                else:
                    score = dark / known
                    state = DARK

                if score >= self._majority_pct / 100.0 and score > best_score:
                    best_score = score
                    best_state = state

        return best_state

    def probe(self, x: int, y: int) -> RGB | None:
        """取单个点的原始 RGB，用于标定时抄数值。"""
        if self._screen is None:
            return None

        pixmap = self._screen.grabWindow(0, x, y, 1, 1)
        if pixmap.isNull():
            return None

        color = pixmap.toImage().pixelColor(0, 0)
        return color.red(), color.green(), color.blue()

    def describe_mapping(self) -> str:
        """给人看的一句话说明，启动时打印。"""
        ax, ay, aw, ah = self._area
        ref_w, ref_h = self._reference
        return (
            f"画面区域 ({ax}, {ay}) {aw}×{ah}，"
            f"参考 {ref_w}×{ref_h}，缩放 {self._scale:.3f}"
        )
