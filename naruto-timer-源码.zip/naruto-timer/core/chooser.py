"""启动时选择自己在哪一侧（P1 左 / P2 右）。

游戏里双方各有一套替身豆，位置左右对称但含义不同。只盯自己那一侧
就够了，对面那套不用管，否则两边都会触发计时，看着乱。
"""

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout


class PlayerChooser(QDialog):
    """一个只有两个大按钮的小窗，选完就关。"""

    def __init__(self, current: str = "p1", parent=None) -> None:
        super().__init__(parent)

        self.choice: str | None = None

        self.setWindowTitle("替身计时器")
        self.setFixedSize(400, 200)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.setStyleSheet(
            "QDialog { background-color: #16202a; }"
            "QLabel { color: #eaf4f4; }"
            "QPushButton { background-color: #22333f; color: #eaf4f4;"
            "  border: 1px solid #3f6070; border-radius: 8px; padding: 10px; }"
            "QPushButton:hover { background-color: #2e4a5a; border-color: #5ac8c8; }"
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(14)

        title = QLabel("你是哪一方？")
        title.setFont(QFont("Microsoft YaHei", 15))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        hint = QLabel("选定后监测【对面】那一侧的替身")
        hint.setFont(QFont("Microsoft YaHei", 10))
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet("color: #8fb0bd;")
        layout.addWidget(hint)

        row = QHBoxLayout()
        row.setSpacing(14)

        for text, value in (("P1 · 我在左侧", "p1"), ("P2 · 我在右侧", "p2")):
            button = QPushButton(text + ("  ✓" if value == current else ""))
            button.setFont(QFont("Microsoft YaHei", 14))
            button.setMinimumHeight(68)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _checked=False, v=value: self._pick(v))
            row.addWidget(button)

        layout.addLayout(row)

    def _pick(self, value: str) -> None:
        self.choice = value
        self.accept()
