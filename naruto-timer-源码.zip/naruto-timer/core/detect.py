"""像素判定核心，纯逻辑、不依赖 Qt，方便单元测试。

判定策略：
    不用「把每种颜色组合逐个列举」的写法（4 个豆 3 种颜色就是 81 种组合，
    每多一个豆还要再翻三倍）。只靠两条规则：

        1. 亮着的豆有几个，剩余替身就是几个（豆按顺序消耗）
        2. 数量下降才算「用掉一次」（下降沿），数量不变或回升都不触发

    好处是不用为每种组合写分支，豆的数量从 4 个改成 5 个也不用改代码。
"""

from __future__ import annotations

import time

RGB = tuple[int, int, int]
Point = tuple[int, int]

DARK = "dark"
BRIGHT = "bright"
GOLD = "gold"

# 判定顺序不能改：赤金的 RGB 区间和亮蓝有重叠（R 通道都能到 180 以上），
# 必须先判赤金，否则特殊忍具形态会被误判成可用替身。
CLASSIFY_ORDER: tuple[str, ...] = (GOLD, BRIGHT, DARK)


def in_range(rgb: RGB, low: RGB, high: RGB, tolerance: int = 0) -> bool:
    """三个通道是否同时落在 [low - tolerance, high + tolerance] 内。"""
    return (
        low[0] - tolerance <= rgb[0] <= high[0] + tolerance
        and low[1] - tolerance <= rgb[1] <= high[1] + tolerance
        and low[2] - tolerance <= rgb[2] <= high[2] + tolerance
    )


def classify(rgb: RGB, palette: dict[str, dict[str, list[int]]], tolerance: int = 0) -> str | None:
    """把单个像素归到 gold / bright / dark，都不沾边返回 None。

    palette 形如 {"bright": {"min": [r,g,b], "max": [r,g,b]}, ...}
    """
    for name in CLASSIFY_ORDER:
        band = palette.get(name)
        if not band:
            continue
        low = tuple(band["min"])  # type: ignore[arg-type]
        high = tuple(band["max"])  # type: ignore[arg-type]
        if in_range(rgb, low, high, tolerance):  # type: ignore[arg-type]
            return name
    return None


def count_available(states: list[str | None]) -> int | None:
    """数还剩几个可用替身。

    注意这里把 bright 和 gold 都算作"亮着的豆"：赤金不是另一种替身，
    而是柱间 / 六尾鸣人这类形态下替身豆的显示颜色，实战验证过——
    这类形态下 6 颗豆全变赤金，但仍然可以正常使用替身。
    只有暗青（dark）代表已经用掉、正在冷却。

    未识别（None）的点不参与计数。若未知点超过一半，说明这一帧画面
    可能还没加载完或窗口被遮挡，直接返回 None 让调用方跳过。
    """
    known = [s for s in states if s is not None]
    if not known:
        return None
    if len(known) * 2 < len(states):
        return None
    return sum(1 for s in known if s in (BRIGHT, GOLD))


def _is_light(state: str) -> bool:
    return state in (BRIGHT, GOLD)


def prefix_violated(states: list[str | None]) -> bool:
    """这一排豆的颜色排列是否自相矛盾。

    豆是按顺序充能/消耗的，所以正常画面只会出现两种排列：

        亮 亮 暗 暗      （从豆1 开始亮）
        暗 暗 亮 亮      （从豆1 开始暗，即从另一端亮）

    出现「亮 暗 亮」这种交替，说明中间至少有一颗读错了——技能特效盖住
    了某颗豆、坐标偏到描边上、或者背景色撞进了区间。这时候宁可丢这一
    帧，也不要拿一个错误的数量去判断"少了没有"，否则会凭空冒倒计时。

    两种方向都接受（不然方向判断错了会把全部正常画面判成脏帧），只有
    两边都不成立才算矛盾。
    """
    known = [s for s in states if s is not None]
    if len(known) < 3:
        # 少于 3 颗看不出排列规律，不下结论
        return False

    # 模式 A：亮在前（亮…亮 暗…暗）
    seen_dark = False
    light_first_ok = True
    for state in known:
        if _is_light(state):
            if seen_dark:
                light_first_ok = False
                break
        else:
            seen_dark = True

    # 模式 B：暗在前（暗…暗 亮…亮）
    seen_light = False
    dark_first_ok = True
    for state in known:
        if _is_light(state):
            seen_light = True
        elif seen_light:
            dark_first_ok = False
            break

    return not (light_first_ok or dark_first_ok)


class EdgeCounter:
    """下降沿计数：只在数值变小时报告"用掉了几个"。

    第一次调用只记录基线、返回 0 —— 冷启动时读到什么状态都不该算作
    "刚用掉一个"，必须先建立基准再比较。
    """

    def __init__(self) -> None:
        self._last: int | None = None

    @property
    def last(self) -> int | None:
        return self._last

    def update(self, current: int) -> int:
        if self._last is None:
            self._last = current
            return 0

        used = self._last - current
        self._last = current

        # 一次替身只会让豆少一颗。少了两颗以上，基本可以断定是画面在切换
        # —— 打出结算、进下一局、切出对局、加载界面都会让整排豆一起消失，
        # 这时候不能触发计时，否则每打完一局都会莫名开始倒数。
        return 1 if used == 1 else 0

    def reset(self) -> None:
        self._last = None


class SideTracker:
    """单侧的完整跟踪：像素状态 → 本次用掉几个替身。

    这里叠了三层防误读：

    1. **排列校验**（prefix_check）：亮/暗的排列必须是从某一端起连续的，
       出现「亮 暗 亮」说明中间读错了，整帧作废。
    2. **多帧确认**（confirm_frames）：连续 N 帧读到同一个数量才采信。
       技能特效闪一下、受击抖动一帧，都不会被当成"少了一个替身"。
    3. **最小触发间隔**（min_gap）：两次触发至少隔这么多秒。替身冷却
       是 15 秒，3 秒内不可能连用两个，所以这个间隔拦掉的一定是误判。
    """

    def __init__(
        self,
        confirm_frames: int = 2,
        min_gap: float = 3.0,
        prefix_check: bool = True,
    ) -> None:
        self._edge = EdgeCounter()
        self._confirm = max(1, int(confirm_frames))
        self._min_gap = max(0.0, float(min_gap))
        self._prefix_check = bool(prefix_check)
        self._pending: int | None = None
        self._pending_count = 0
        self._last_trigger_at = 0.0
        self.remaining: int | None = None
        self.skipped = 0  # 被排列校验拦掉的帧数，便于排查

    def feed(self, states: list[str | None]) -> int:
        """喂一帧的分类结果，返回本帧确认消耗的替身数量（只可能是 0 或 1）。

        只要这一帧里有任何一个点没识别出来，就只更新基准、不参与确认。
        None 会让可用数凭空少一个，照常判断就会冒出假倒计时。
        """
        count = count_available(states)
        if count is None:
            return 0

        # 排列自相矛盾：这一帧某个点八成读错了。整帧作废，连基准都不更新
        # —— 用错的数量当基准，等下次读到正确值时会被算成"掉了一颗"，
        # 反而凭空冒出一个倒计时。
        if self._prefix_check and prefix_violated(states):
            self.skipped += 1
            self._pending = None
            self._pending_count = 0
            return 0

        if any(state is None for state in states):
            self._pending = None
            self._pending_count = 0
            self._edge.update(count)
            return 0

        # 多帧确认：读数没变就累计，一变就从头数
        if count == self._pending:
            self._pending_count += 1
        else:
            self._pending = count
            self._pending_count = 1

        if self._pending_count < self._confirm:
            return 0

        self.remaining = count
        used = self._edge.update(count)
        if not used:
            return 0

        now = time.monotonic()
        if now - self._last_trigger_at < self._min_gap:
            return 0

        self._last_trigger_at = now
        return used

    def reset(self) -> None:
        self._edge.reset()
        self._pending = None
        self._pending_count = 0
        self.remaining = None
