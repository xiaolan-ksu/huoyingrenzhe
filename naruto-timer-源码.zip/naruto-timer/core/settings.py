"""设置窗口：调判定参数。

热键已经全部改成面板按钮，所以这里只留三个数值参数。
"""

from __future__ import annotations

from typing import Any

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
)

STYLE = """
QDialog { background-color: #131e26; }
QLabel { color: #d8e8ee; font-size: 12px; }
QGroupBox {
    color: #7fd8d0; border: 1px solid #2b4552; border-radius: 8px;
    margin-top: 12px; padding-top: 10px; font-size: 12px;
}
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QPushButton {
    background-color: #22333f; color: #e8f4f8; border: 1px solid #3f6070;
    border-radius: 6px; padding: 6px 16px; font-size: 12px;
}
QPushButton:hover { background-color: #2e4a5a; border-color: #5ac8c8; }
QPushButton:pressed { background-color: #1a2a34; }
QSpinBox, QDoubleSpinBox {
    background-color: #1b2b35; color: #e8f4f8; border: 1px solid #3f6070;
    border-radius: 5px; padding: 4px 6px; font-size: 12px;
}
"""

HELP_TEXT = (
    "面板按钮：点数字=手动打点　P1⇄=换边　☰=设置　◎=显示检测点（可拖动标定）"
    "　⏸=暂停检测　↺=清空计时"
)


class SettingsDialog(QDialog):
    """只调判定参数。"""

    def __init__(self, cfg: dict[str, Any], parent=None) -> None:
        super().__init__(parent)

        self.setWindowTitle("替身计时器 · 设置")
        self.setFixedWidth(400)
        self.setStyleSheet(STYLE)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(12)

        group = QGroupBox("判定参数")
        form = QFormLayout(group)
        form.setSpacing(10)

        self._seconds = QDoubleSpinBox()
        self._seconds.setRange(5.0, 30.0)
        self._seconds.setSingleStep(0.1)
        self._seconds.setDecimals(1)
        self._seconds.setValue(float(cfg["countdown_seconds"]))
        form.addRow(QLabel("替身冷却（秒）"), self._seconds)

        det = cfg["detection"]
        self._confirm = QSpinBox()
        self._confirm.setRange(1, 5)
        self._confirm.setValue(int(det.get("confirm_frames", 2)))
        form.addRow(QLabel("多帧确认（帧）"), self._confirm)

        self._gap = QDoubleSpinBox()
        self._gap.setRange(0.0, 30.0)
        self._gap.setSingleStep(0.5)
        self._gap.setDecimals(1)
        self._gap.setValue(float(det.get("min_trigger_gap", 3.0)))
        form.addRow(QLabel("最小触发间隔（秒）"), self._gap)

        hint = QLabel(
            "多帧确认：连续几帧读数一致才采信，越大越稳、反应越慢。\n"
            "最小间隔：两次触发之间的最短时间，防止连续误报。"
        )
        hint.setStyleSheet("color: #7f9aa6; font-size: 11px;")
        hint.setWordWrap(True)
        form.addRow(hint)

        layout.addWidget(group)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("取消")
        cancel.clicked.connect(self.reject)
        save = QPushButton("保存")
        save.setDefault(True)
        save.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        layout.addLayout(buttons)

        help_label = QLabel(HELP_TEXT)
        help_label.setStyleSheet("color: #6f8b96; font-size: 10px;")
        help_label.setWordWrap(True)
        help_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(help_label)

    def values(self) -> dict[str, Any]:
        return {
            "countdown_seconds": self._seconds.value(),
            "confirm_frames": self._confirm.value(),
            "min_trigger_gap": self._gap.value(),
        }
