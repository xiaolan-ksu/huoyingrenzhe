"""替身计时器悬浮面板（自绘）。

布局（240×130）：

    ┌────────────────────────────────┐
    │ [P1 ⇄] [☰] [◎] [⏸] [↺]        │  ← 工具行
    │                                │
    │           12.9                 │  ← 点这里手动打一次计时
    │       ▓▓▓▓▓▓░░░░               │
    │           状态提示             │
    └────────────────────────────────┘

所有操作都在这块面板上，不再占用全局热键：
    点数字    手动打一次计时
    P1 ⇄      换边（自己在左还是在右）
    ☰         设置（冷却秒数、判定参数）
    ◎         显示 / 隐藏检测点（拖动圆圈可标定）
    ⏸         暂停 / 恢复像素检测
    ↺         清空当前计时
"""

from __future__ import annotations

import time
from typing import Any

from PyQt6.QtCore import QPoint, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QIcon, QPainter, QPen, QPixmap
from PyQt6.QtWidgets import QMenu, QSystemTrayIcon, QWidget

BG = QColor(8, 20, 28, 215)
BORDER = QColor(90, 200, 220, 110)
CYAN = QColor(90, 224, 208)
AMBER = QColor(255, 200, 90)
RED = QColor(255, 107, 107)
DIM = QColor(120, 160, 172)
BTN_BORDER = QColor(90, 200, 220, 140)
BTN_FILL = QColor(90, 200, 220, 34)

BTN_H = 24
BTN_Y = 10
SIDE_BTN = QRectF(12, BTN_Y, 56, BTN_H)
SETTINGS_BTN = QRectF(72, BTN_Y, 26, BTN_H)
DEBUG_BTN = QRectF(102, BTN_Y, 26, BTN_H)
PAUSE_BTN = QRectF(132, BTN_Y, 26, BTN_H)
CLEAR_BTN = QRectF(162, BTN_Y, 26, BTN_H)
DIGIT_AREA = QRectF(0, 42, 240, 52)


class Overlay(QWidget):
    """悬浮面板，全部按钮化，不依赖全局热键。"""

    quit_requested = pyqtSignal()
    switch_side = pyqtSignal()
    open_settings = pyqtSignal()
    toggle_debug = pyqtSignal()
    toggle_pause = pyqtSignal()
    clear_requested = pyqtSignal()
    manual_trigger = pyqtSignal()

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()

        self._cfg = cfg
        win = cfg["window"]
        self.setGeometry(win["x"], win["y"], win["width"], win["height"])
        self.setWindowTitle("替身计时器")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)

        self._total = float(cfg["countdown_seconds"])
        self._player = "p1"
        self._deadline: float | None = None
        self._paused = False
        self._debug_on = False
        self._status_text = ""
        self._status_until = 0.0
        self._drag_offset: QPoint | None = None

        self._ticker = QTimer(self)
        self._ticker.setInterval(50)
        self._ticker.timeout.connect(self._on_tick)
        self._ticker.start()

        self._tray: QSystemTrayIcon | None = None
        self._build_tray()

    # ---------- 对外接口 ----------

    def set_player(self, player: str) -> None:
        self._player = player
        self.update()

    def set_total(self, seconds: float) -> None:
        self._total = max(0.1, float(seconds))
        self.update()

    def set_paused(self, paused: bool) -> None:
        self._paused = paused
        self.update()

    def set_debug(self, enabled: bool) -> None:
        self._debug_on = enabled
        self.update()

    def start_countdown(self) -> None:
        self._deadline = time.monotonic() + self._total
        self.update()

    def clear(self) -> None:
        self._deadline = None
        self.update()

    def show_status(self, text: str, duration_ms: int = 3000) -> None:
        self._status_text = text
        self._status_until = time.monotonic() + duration_ms / 1000.0
        self.update()

    # ---------- 内部 ----------

    def _on_tick(self) -> None:
        now = time.monotonic()
        dirty = False

        if self._deadline is not None:
            if now >= self._deadline:
                self._deadline = None
            dirty = True

        if self._status_text and now >= self._status_until:
            self._status_text = ""
            dirty = True

        if dirty:
            self.update()

    def _remaining(self) -> float | None:
        if self._deadline is None:
            return None
        return max(0.0, self._deadline - time.monotonic())

    def _color_for(self, left: float) -> QColor:
        if left <= 2:
            return RED
        if left <= 5:
            return AMBER
        return CYAN

    # ---------- 托盘 ----------

    def _build_tray(self) -> None:
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return

        pixmap = QPixmap(32, 32)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(CYAN)
        painter.drawEllipse(2, 2, 28, 28)
        painter.end()

        menu = QMenu()
        menu.addAction("切换边（P1 / P2）", self.switch_side.emit)
        menu.addAction("清空计时", self.clear_requested.emit)
        menu.addAction("设置", self.open_settings.emit)
        menu.addAction("显示 / 隐藏面板", self.toggle_visible)
        menu.addSeparator()
        menu.addAction("退出", self.quit_requested.emit)

        self._tray = QSystemTrayIcon(QIcon(pixmap), self)
        self._tray.setToolTip("替身计时器")
        self._tray.setContextMenu(menu)
        self._tray.activated.connect(
            lambda reason: self.toggle_visible()
            if reason == QSystemTrayIcon.ActivationReason.Trigger
            else None
        )
        self._tray.show()

    def toggle_visible(self) -> None:
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()

    # ---------- 绘制 ----------

    def _draw_chip(self, painter: QPainter, rect: QRectF, active: bool = False) -> None:
        painter.setPen(QPen(CYAN if active else BTN_BORDER, 1))
        painter.setBrush(QColor(90, 200, 220, 70) if active else BTN_FILL)
        painter.drawRoundedRect(rect, 6, 6)
        painter.setPen(QPen(CYAN, 1.6))
        painter.setBrush(Qt.BrushStyle.NoBrush)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        body = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setPen(QPen(BORDER, 1))
        painter.setBrush(BG)
        painter.drawRoundedRect(body, 12, 12)

        # 换边
        self._draw_chip(painter, SIDE_BTN)
        painter.setFont(QFont("Microsoft YaHei", 9))
        painter.drawText(SIDE_BTN, Qt.AlignmentFlag.AlignCenter, f"{self._player.upper()} ⇄")

        # 设置：三条横线
        self._draw_chip(painter, SETTINGS_BTN)
        cx, cy = SETTINGS_BTN.center().x(), SETTINGS_BTN.center().y()
        for offset in (-5.0, 0.0, 5.0):
            painter.drawLine(int(cx - 6), int(cy + offset), int(cx + 6), int(cy + offset))

        # 标定：圆 + 中心点
        self._draw_chip(painter, DEBUG_BTN, active=self._debug_on)
        dcx, dcy = DEBUG_BTN.center().x(), DEBUG_BTN.center().y()
        painter.drawEllipse(QRectF(dcx - 6, dcy - 6, 12, 12))
        painter.setBrush(CYAN)
        painter.drawEllipse(QRectF(dcx - 1.5, dcy - 1.5, 3, 3))
        painter.setBrush(Qt.BrushStyle.NoBrush)

        # 暂停 / 播放
        self._draw_chip(painter, PAUSE_BTN, active=self._paused)
        pcx, pcy = PAUSE_BTN.center().x(), PAUSE_BTN.center().y()
        if self._paused:
            painter.drawLine(int(pcx - 4), int(pcy - 6), int(pcx - 4), int(pcy + 6))
            painter.drawLine(int(pcx - 4), int(pcy - 6), int(pcx + 5), int(pcy))
            painter.drawLine(int(pcx - 4), int(pcy + 6), int(pcx + 5), int(pcy))
        else:
            painter.drawLine(int(pcx - 4), int(pcy - 6), int(pcx - 4), int(pcy + 6))
            painter.drawLine(int(pcx + 4), int(pcy - 6), int(pcx + 4), int(pcy + 6))

        # 清空：圆弧 + 箭头
        self._draw_chip(painter, CLEAR_BTN)
        ccx, ccy = CLEAR_BTN.center().x(), CLEAR_BTN.center().y()
        painter.drawArc(QRectF(ccx - 6, ccy - 6, 12, 12), 40 * 16, 280 * 16)
        painter.drawLine(int(ccx + 3), int(ccy - 8), int(ccx + 7), int(ccy - 4))

        # 中央倒计时
        left = self._remaining()
        if self._paused:
            text, color = "暂停", DIM
        elif left is None:
            text, color = "就绪", QColor(120, 165, 175)
        else:
            text = f"{left:.1f}"
            color = self._color_for(left)

        painter.setPen(QPen(color))
        painter.setFont(QFont("Microsoft YaHei", 30, QFont.Weight.Bold))
        painter.drawText(DIGIT_AREA, Qt.AlignmentFlag.AlignCenter, text)

        # 进度条
        bar = QRectF(20, 96, self.width() - 40, 6)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(255, 255, 255, 28))
        painter.drawRoundedRect(bar, 3, 3)

        if left is not None and self._total > 0:
            ratio = max(0.0, min(1.0, left / self._total))
            if ratio > 0.002:
                painter.setBrush(color)
                painter.drawRoundedRect(
                    QRectF(bar.x(), bar.y(), bar.width() * ratio, bar.height()), 3, 3
                )

        # 状态提示
        if self._status_text:
            painter.setPen(QPen(QColor(190, 225, 235, 230)))
            painter.setFont(QFont("Microsoft YaHei", 8))
            painter.drawText(
                QRectF(0, 106, self.width(), 16),
                Qt.AlignmentFlag.AlignCenter,
                self._status_text,
            )

    # ---------- 交互 ----------

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() != Qt.MouseButton.LeftButton:
            return

        pos = event.position()

        if SIDE_BTN.contains(pos):
            self.switch_side.emit()
            return
        if SETTINGS_BTN.contains(pos):
            self.open_settings.emit()
            return
        if DEBUG_BTN.contains(pos):
            self.toggle_debug.emit()
            return
        if PAUSE_BTN.contains(pos):
            self.toggle_pause.emit()
            return
        if CLEAR_BTN.contains(pos):
            self.clear_requested.emit()
            return
        if DIGIT_AREA.contains(pos):
            self.manual_trigger.emit()
            return

        self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        self._drag_offset = None

    def closeEvent(self, event) -> None:  # noqa: N802
        self.quit_requested.emit()
        super().closeEvent(event)
