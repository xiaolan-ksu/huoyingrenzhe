"""离屏冒烟测试：验证新面板的绘制、倒计时和换边逻辑。

不依赖显示器，用 Qt 的 offscreen 平台插件跑：
    python tests/smoke_test.py
"""

from __future__ import annotations

import copy
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from PyQt6.QtCore import QTimer  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from core import config as config_module  # noqa: E402
from core.overlay import Overlay  # noqa: E402


def main() -> int:
    cfg = copy.deepcopy(config_module.load(ROOT / "config.json"))
    cfg["countdown_seconds"] = 0.4

    app = QApplication([])
    app.setQuitOnLastWindowClosed(False)

    overlay = Overlay(cfg)
    overlay.show()
    overlay.set_player("p1")

    print(f"窗口尺寸 {overlay.width()}×{overlay.height()}")
    assert overlay.width() == 240, "窗口宽度应为 240"

    overlay.start_countdown()
    print("倒计时已启动")

    snapshot: dict[str, object] = {}

    def check_running() -> None:
        snapshot["left"] = overlay._remaining()
        print(f"0.2 秒时剩余 {snapshot['left']:.2f}")

    def check_finished() -> None:
        snapshot["after"] = overlay._remaining()

    def do_switch() -> None:
        overlay.switch_side.emit()

    overlay.switch_side.connect(lambda: snapshot.update(switch_fired=True))

    QTimer.singleShot(200, check_running)
    QTimer.singleShot(700, check_finished)
    QTimer.singleShot(800, do_switch)
    QTimer.singleShot(1000, app.quit)
    app.exec()

    left = snapshot.get("left")
    assert isinstance(left, float) and 0.0 < left <= 0.4, "倒计时应在走"
    assert snapshot.get("after") is None, "倒计时结束后 deadline 应清空"
    assert snapshot.get("switch_fired"), "换边信号应该发出来"

    # 换边后重新计时不应该报错
    overlay.set_player("p2")
    overlay.start_countdown()
    overlay.clear()

    print("换边信号正常，倒计时归零正常")
    print("冒烟测试通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
