"""坐标映射与菱形采样的单元测试。

不需要真实游戏画面：豆用 QImage 合成，映射用纯计算验证。
跑法：
    cd naruto-timer
    python -m unittest discover -s tests -v
"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PyQt6.QtGui import QColor, QImage  # noqa: E402
from PyQt6.QtWidgets import QApplication  # noqa: E402

from core import config as config_module  # noqa: E402
from core.sampler import Region, ScreenSampler  # noqa: E402

_APP = QApplication.instance() or QApplication([])

CFG = config_module.load(Path(__file__).resolve().parent.parent / "config.json")

BG_GAME = (44, 62, 38)        # 决斗场背景，暗绿
BG_DESKTOP = (240, 240, 240)  # 亮色桌面


def make_bead_image(bg, bead, width=40, height=40, half_w=10, half_h=12, ox=0, oy=0):
    """合成一张"背景 + 居中菱形豆"的图。half_w/half_h 是豆的半宽半高。"""
    img = QImage(width, height, QImage.Format.Format_RGB32)
    img.fill(QColor(*bg))
    cx, cy = width // 2 + ox, height // 2 + oy
    for dy in range(-half_h, half_h + 1):
        for dx in range(-half_w, half_w + 1):
            if abs(dx) * half_h + abs(dy) * half_w > half_w * half_h:
                continue
            x, y = cx + dx, cy + dy
            if 0 <= x < width and 0 <= y < height:
                img.setPixelColor(x, y, QColor(*bead))
    return img


class TestMapping(unittest.TestCase):
    """坐标映射：换分辨率不重标就靠这一层。"""

    def setUp(self):
        self.sampler = ScreenSampler(CFG)

    def _use(self, area):
        self.sampler._area = area
        self.sampler._refresh()

    def test_1080p_is_identity(self):
        self._use((0, 0, 1920, 1080))
        self.assertEqual(self.sampler._map((212, 126)), (212, 126))
        self.assertEqual(self.sampler._map((1710, 124)), (1710, 124))

    def test_left_point_scales_with_height(self):
        """1440p：左豆按高度等比放大。"""
        self._use((0, 0, 2560, 1440))
        self.assertEqual(self.sampler._map((212, 126)), (283, 168))

    def test_right_point_anchors_to_right_edge(self):
        """1440p：右豆从右边界往回数，不受中间场景宽度影响。"""
        self._use((0, 0, 2560, 1440))
        # 距右边界 1920-1623=297 逻辑像素，放大 1.333 后离右边界 396
        self.assertEqual(self.sampler._map((1623, 126)), (2164, 168))

    def test_ultrawide_keeps_hud_at_edges(self):
        """超宽画面：左右 HUD 仍然贴边，不会被拉到中间。"""
        self._use((0, 0, 2560, 1080))
        self.assertEqual(self.sampler._map((212, 126))[0], 212)
        self.assertEqual(self.sampler._map((1710, 124))[0], 2350)

    def test_window_offset_applied(self):
        """窗口模式：整体偏移到窗口客户区。"""
        self._use((170, 16, 1920, 1080))
        self.assertEqual(self.sampler._map((212, 126)), (382, 142))

    def test_roundtrip_preserves_coordinates(self):
        """往返换算不能漂移。

        画面被缩小（比如窗口模式 0.83 倍）时，一个物理像素对应 1.2 个
        逻辑像素，取整必然有 ±1 的损失，这属于精度上限而非逻辑错误。
        """
        for area in ((0, 0, 1920, 1080), (0, 0, 2560, 1440), (170, 16, 1600, 900)):
            self._use(area)
            for point in ((212, 126), (303, 125), (1623, 126), (1710, 124)):
                back = self.sampler.unmap(self.sampler._map(point))
                self.assertLessEqual(
                    abs(back[0] - point[0]) + abs(back[1] - point[1]),
                    1,
                    f"区域 {area} 下 {point} 往返变成 {back}，偏差超过 1 像素",
                )


class TestDiamondSampling(unittest.TestCase):
    """菱形采样 + 多数决：豆在的时候要读得准，不在的时候不能瞎认。"""

    def setUp(self):
        self.sampler = ScreenSampler(CFG)
        self.sampler._area = (0, 0, 1920, 1080)
        self.sampler._refresh()
        self.region = Region(0, 0, 40, 40, [(20, 20)])

    def read(self, img):
        return self.sampler._read_point(img, 20, 20, self.region)

    def test_bright_bead(self):
        img = make_bead_image(BG_GAME, (154, 230, 248))
        self.assertEqual(self.read(img), "bright")

    def test_gold_bead(self):
        img = make_bead_image(BG_GAME, (255, 200, 60))
        self.assertEqual(self.read(img), "gold")

    def test_dark_bead(self):
        img = make_bead_image(BG_GAME, (27, 54, 97))
        self.assertEqual(self.read(img), "dark")

    def test_bright_on_light_background(self):
        """浅色桌面上也要读得出，不能因为背景亮就判成亮豆。"""
        img = make_bead_image(BG_DESKTOP, (154, 230, 248))
        self.assertEqual(self.read(img), "bright")

    def test_empty_background_is_none(self):
        """没有豆的地方必须返回 None，否则整排豆的状态会凭空变化。"""
        img = make_bead_image(BG_GAME, BG_GAME)
        self.assertIsNone(self.read(img))

    def test_white_frame_is_none(self):
        """白屏（加载/切场景）不能认成亮豆。"""
        img = make_bead_image((255, 255, 255), (255, 255, 255))
        self.assertIsNone(self.read(img))

    def test_offsets_are_recovered(self):
        """坐标偏几个像素时，靠搜索找回豆心。

        这是换分辨率后不用重标的第二道保险：映射算出来的位置差两三像素，
        采样自己会纠回来。
        """
        for ox, oy in ((3, 0), (-3, 0), (0, 3), (0, -3), (2, 2)):
            img = make_bead_image(BG_GAME, (154, 230, 248), ox=ox, oy=oy)
            self.assertEqual(self.read(img), "bright", f"偏移 ({ox},{oy}) 时读错了")

    def test_small_bead_still_readable(self):
        """豆比较小的时候（低分辨率或角色差异）也要能读。"""
        img = make_bead_image(BG_GAME, (27, 54, 97), half_w=7, half_h=9)
        self.assertEqual(self.read(img), "dark")


if __name__ == "__main__":
    unittest.main(verbosity=2)
