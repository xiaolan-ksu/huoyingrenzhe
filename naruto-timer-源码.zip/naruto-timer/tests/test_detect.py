"""像素判定的单元测试（不依赖 Qt）。

跑法：
    cd naruto-timer
    python -m unittest discover -s tests -v
"""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.detect import (  # noqa: E402
    BRIGHT,
    DARK,
    GOLD,
    EdgeCounter,
    SideTracker,
    classify,
    count_available,
    in_range,
    prefix_violated,
)

# 与 config.json 里 detection.colors 保持一致的实测区间
PALETTE = {
    "dark":   {"min": [8, 28, 70],     "max": [75, 80, 125]},
    "gold":   {"min": [165, 150, 0],   "max": [255, 255, 145]},
    "bright": {"min": [100, 180, 210], "max": [220, 255, 255]},
}

DARK_RGB = (30, 50, 96)      # 实测 (25~27, 50~57, 96~99)
BRIGHT_RGB = (154, 230, 248)  # 实测 (141~177, 224~239, 245~251)
GOLD_RGB = (255, 200, 60)     # 实测 (189~255, 189~246, 0~125)


class TestInRange(unittest.TestCase):
    def test_inside(self):
        self.assertTrue(in_range(DARK_RGB, (8, 28, 70), (75, 80, 125)))

    def test_outside(self):
        self.assertFalse(in_range((200, 200, 200), (8, 28, 70), (75, 80, 125)))

    def test_tolerance_expands_bounds(self):
        low, high = (8, 28, 70), (75, 80, 125)
        # 超出上限 3，容差 4 时应该算命中
        self.assertTrue(in_range((78, 80, 125), low, high, tolerance=4))
        # 超出上限 5，容差 4 时应该算不中
        self.assertFalse(in_range((80, 80, 125), low, high, tolerance=4))


class TestClassify(unittest.TestCase):
    def test_dark(self):
        self.assertEqual(classify(DARK_RGB, PALETTE), DARK)

    def test_bright(self):
        self.assertEqual(classify(BRIGHT_RGB, PALETTE), BRIGHT)

    def test_gold(self):
        self.assertEqual(classify(GOLD_RGB, PALETTE), GOLD)

    def test_white_background_is_not_a_bean(self):
        """白色背景不能落进任何区间，否则切到桌面就会误判。"""
        self.assertIsNone(classify((255, 255, 255), PALETTE))

    def test_orange_title_is_not_gold(self):
        """游戏加载页的橙色标题 G 通道偏低，不能当成赤金豆。"""
        self.assertIsNone(classify((255, 143, 35), PALETTE))

    def test_classify_order_prefers_gold(self):
        """两个区间重叠时必须先判 gold。

        当前实测的三组色值互不重叠，但 CLASSIFY_ORDER 的顺序仍然要有
        保障——一旦以后放宽某个区间产生交集，判定顺序错了就会把已用的
        豆算成可用，倒计时直接不触发。所以这里用构造的重叠调色板来测。
        """
        overlapping_palette = {
            "gold":   {"min": [150, 100, 0],   "max": [255, 255, 200]},
            "bright": {"min": [0, 100, 100],   "max": [255, 255, 255]},
        }
        # 这个颜色同时落在两个区间里
        self.assertTrue(in_range((200, 180, 150), (150, 100, 0), (255, 255, 200)))
        self.assertTrue(in_range((200, 180, 150), (0, 100, 100), (255, 255, 255)))
        self.assertEqual(classify((200, 180, 150), overlapping_palette), GOLD)

    def test_unmatched_returns_none(self):
        self.assertIsNone(classify((255, 0, 255), PALETTE))


class TestCountAvailable(unittest.TestCase):
    def test_counts_bright_only(self):
        states = [BRIGHT, BRIGHT, DARK, DARK, DARK, DARK]
        self.assertEqual(count_available(states), 2)

    def test_gold_counts_as_available(self):
        """柱间 / 六尾鸣人形态下豆显示为赤金，一样是可用替身。"""
        states = [GOLD, BRIGHT, DARK, DARK]
        self.assertEqual(count_available(states), 2)

    def test_all_gold(self):
        states = [GOLD] * 6
        self.assertEqual(count_available(states), 6)

    def test_all_none_produces_none(self):
        self.assertIsNone(count_available([None, None, None]))

    def test_too_many_unknown_produces_none(self):
        states = [BRIGHT, None, None, None]
        self.assertIsNone(count_available(states))

    def test_minor_unknown_tolerated(self):
        states = [BRIGHT, BRIGHT, DARK, None]
        self.assertEqual(count_available(states), 2)


class TestPrefixViolated(unittest.TestCase):
    """排列校验：豆按顺序充能，只会出现「亮在前」或「暗在前」两种排列。"""

    def test_light_first_is_legal(self):
        self.assertFalse(prefix_violated([BRIGHT, BRIGHT, DARK, DARK]))

    def test_dark_first_is_legal(self):
        """左侧豆位是从屏幕外向里排的，实测出现过第一个先暗的排列。"""
        self.assertFalse(prefix_violated([DARK, BRIGHT, BRIGHT, BRIGHT]))

    def test_all_light_is_legal(self):
        self.assertFalse(prefix_violated([BRIGHT] * 4))

    def test_all_dark_is_legal(self):
        self.assertFalse(prefix_violated([DARK] * 4))

    def test_gold_counts_as_light(self):
        self.assertFalse(prefix_violated([GOLD, GOLD, DARK, DARK]))

    def test_alternating_is_illegal(self):
        """亮-暗-亮 说明中间那颗读错了。"""
        self.assertTrue(prefix_violated([BRIGHT, DARK, BRIGHT, BRIGHT]))
        self.assertTrue(prefix_violated([DARK, BRIGHT, DARK, DARK]))

    def test_hole_in_middle_is_illegal(self):
        self.assertTrue(prefix_violated([BRIGHT, BRIGHT, DARK, BRIGHT]))

    def test_unknown_points_ignored(self):
        """看不清的点不参与判断，不能因此判成矛盾。"""
        self.assertFalse(prefix_violated([BRIGHT, None, BRIGHT, DARK]))

    def test_too_few_points_never_flags(self):
        self.assertFalse(prefix_violated([BRIGHT, DARK]))
        self.assertFalse(prefix_violated([BRIGHT]))
        self.assertFalse(prefix_violated([]))


class TestEdgeCounter(unittest.TestCase):
    def test_first_call_is_baseline(self):
        counter = EdgeCounter()
        self.assertEqual(counter.update(4), 0)

    def test_decrease_reports_consumed(self):
        counter = EdgeCounter()
        counter.update(4)
        self.assertEqual(counter.update(3), 1)

    def test_same_value_reports_nothing(self):
        counter = EdgeCounter()
        counter.update(3)
        self.assertEqual(counter.update(3), 0)
        self.assertEqual(counter.update(3), 0)

    def test_increase_resets_without_trigger(self):
        """回合重新开始、豆回满时不应该误报用掉替身。"""
        counter = EdgeCounter()
        counter.update(1)
        self.assertEqual(counter.update(4), 0)

    def test_dropping_more_than_one_is_ignored(self):
        """一次替身只掉一颗。掉两颗以上说明是对局结束/画面切换，不能触发。"""
        counter = EdgeCounter()
        counter.update(4)
        self.assertEqual(counter.update(2), 0)

    def test_round_end_does_not_trigger(self):
        """打完一局进入下一局时整排豆消失（4→0），不能冒出假计时。"""
        counter = EdgeCounter()
        counter.update(4)
        self.assertEqual(counter.update(0), 0)


class TestSideTracker(unittest.TestCase):
    def test_full_match_flow(self):
        tracker = SideTracker(confirm_frames=1, min_gap=0)
        # 开局 4 个亮豆：只建立基线
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT]), 0)
        # 用掉一个
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 1)
        self.assertEqual(tracker.remaining, 3)
        # 画面没变，不应重复触发
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 0)
        # 数据缺失的一帧不应污染状态
        self.assertEqual(tracker.feed([None, None, None, None]), 0)
        self.assertEqual(tracker.remaining, 3)
        # 恢复后继续正常
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, DARK, DARK]), 1)

    def test_partial_unknown_never_triggers(self):
        """有未识别点时只更新基准，不能因为 None 让数量"变少"就报一次消耗。"""
        tracker = SideTracker(confirm_frames=1, min_gap=0)
        tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT])
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, None]), 0)
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT]), 0)
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 1)

    def test_debounce_requires_consecutive_frames(self):
        """单帧抖动不采信，必须连续两帧读到同一个数量。"""
        tracker = SideTracker(confirm_frames=2, min_gap=0)
        tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT])
        tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT])
        # 只掉了一帧，不采信
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 0)
        # 又跳回满，之前的抖动被丢弃
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT]), 0)
        # 真正掉下来，也要连续两帧才触发
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 0)
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 1)

    def test_min_gap_blocks_repeat_trigger(self):
        """两次触发至少隔 3 秒，防止连续误判刷屏。"""
        tracker = SideTracker(confirm_frames=1, min_gap=3.0)
        tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT])
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 1)
        # 立刻又掉一个，间隔不够，不触发
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, DARK, DARK]), 0)

    def test_reset_clears_baseline(self):
        tracker = SideTracker(confirm_frames=1, min_gap=0)
        tracker.feed([BRIGHT, BRIGHT])
        tracker.reset()
        self.assertEqual(tracker.feed([DARK, DARK]), 0)
        self.assertEqual(tracker.remaining, 0)

    def test_contradictory_frame_is_dropped(self):
        """排列矛盾的帧要整帧作废，连基准都不能更新。

        如果拿错的数量当基准，等下次读到正确值会被算成"掉了一颗"，
        反而凭空冒出一个倒计时。
        """
        tracker = SideTracker(confirm_frames=1, min_gap=0)
        tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT])
        # 中间那颗被特效盖住，读成 亮-暗-亮-亮（3 个亮），矛盾
        self.assertEqual(tracker.feed([BRIGHT, DARK, BRIGHT, BRIGHT]), 0)
        self.assertEqual(tracker.skipped, 1)
        # 恢复正常后是 4 个亮，和最初的基准一致，不该触发
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT]), 0)
        # 真正掉一颗才触发
        self.assertEqual(tracker.feed([BRIGHT, BRIGHT, BRIGHT, DARK]), 1)

    def test_prefix_check_can_be_disabled(self):
        tracker = SideTracker(confirm_frames=1, min_gap=0, prefix_check=False)
        tracker.feed([BRIGHT, BRIGHT, BRIGHT, BRIGHT])
        # 关掉校验后，矛盾帧照常参与计数（数量仍是 3）
        tracker.feed([BRIGHT, DARK, BRIGHT, BRIGHT])
        self.assertEqual(tracker.skipped, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
